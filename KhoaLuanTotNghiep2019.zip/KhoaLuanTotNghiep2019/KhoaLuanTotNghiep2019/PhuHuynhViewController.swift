//
//  PhuHuynhViewController.swift
//  KhoaLuanTotNghiep2019
//
//  Created by Le Ngoc Bao on 5/9/19.
//  Copyright © 2019 Le Ngoc Bao. All rights reserved.
//

import UIKit

class PhuHuynhViewController: UIViewController {
    @IBOutlet weak var btnDangXuat: UIButton!
    @IBOutlet weak var btnThongBao: UIButton!
    @IBOutlet weak var btnLoiNhan: UIButton!
    @IBOutlet weak var imgHinhDaiDien: UIImageView!
    @IBOutlet weak var lblTenHocSinh: UILabel!
    @IBOutlet weak var btnNgayHocHomNay: UIButton!
    @IBOutlet weak var imgHinhAnh: UIImageView!
    @IBOutlet weak var btnAlbum: UIButton!
    @IBOutlet weak var btnTheoDoiSucKhoe: UIButton!
    @IBOutlet weak var btnXinNghiHoc: UIButton!
    @IBOutlet weak var btnDangKyDichVu: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //lblTenHocSinh.layer.borderWidth = 2
        
        btnDangXuat.layer.cornerRadius = 10
        btnDangXuat.layer.shadowColor = UIColor(red:0/255, green: 0/255, blue: 0/255, alpha: 1).cgColor
        btnDangXuat.layer.shadowOffset = CGSize(width: 3, height: 3)
        btnDangXuat.layer.shadowOpacity = 1
        btnDangXuat.layer.shadowRadius = 3
        
        btnThongBao.layer.cornerRadius = 10
        btnThongBao.layer.shadowColor = UIColor(red:0/255, green: 0/255, blue: 0/255, alpha: 1).cgColor
        btnThongBao.layer.shadowOffset = CGSize(width: 3, height: 3)
        btnThongBao.layer.shadowOpacity = 1
        btnThongBao.layer.shadowRadius = 3
        
        btnLoiNhan.layer.cornerRadius = 10
        btnLoiNhan.layer.shadowColor = UIColor(red:0/255, green: 0/255, blue: 0/255, alpha: 1).cgColor
        btnLoiNhan.layer.shadowOffset = CGSize(width: 3, height: 3)
        btnLoiNhan.layer.shadowOpacity = 1
        btnLoiNhan.layer.shadowRadius = 3
        
        btnNgayHocHomNay.layer.cornerRadius = 10
        btnNgayHocHomNay.layer.shadowColor = UIColor(red:0/255, green: 0/255, blue: 0/255, alpha: 1).cgColor
        btnNgayHocHomNay.layer.shadowOffset = CGSize(width: 3, height: 3)
        btnNgayHocHomNay.layer.shadowOpacity = 1
        btnNgayHocHomNay.layer.shadowRadius = 3

        btnAlbum.layer.cornerRadius = 10
        btnAlbum.layer.shadowColor = UIColor(red:0/255, green: 0/255, blue: 0/255, alpha: 1).cgColor
        btnAlbum.layer.shadowOffset = CGSize(width: 3, height: 3)
        btnAlbum.layer.shadowOpacity = 1
        btnAlbum.layer.shadowRadius = 3
        
        btnTheoDoiSucKhoe.layer.cornerRadius = 10
        btnTheoDoiSucKhoe.layer.shadowColor = UIColor(red:0/255, green: 0/255, blue: 0/255, alpha: 1).cgColor
        btnTheoDoiSucKhoe.layer.shadowOffset = CGSize(width: 3, height: 3)
        btnTheoDoiSucKhoe.layer.shadowOpacity = 1
        btnTheoDoiSucKhoe.layer.shadowRadius = 3
        
        btnXinNghiHoc.layer.cornerRadius = 10
        btnXinNghiHoc.layer.shadowColor = UIColor(red:0/255, green: 0/255, blue: 0/255, alpha: 1).cgColor
        btnXinNghiHoc.layer.shadowOffset = CGSize(width: 3, height: 3)
        btnXinNghiHoc.layer.shadowOpacity = 1
        btnXinNghiHoc.layer.shadowRadius = 3
        
        btnDangKyDichVu.layer.cornerRadius = 10
        btnDangKyDichVu.layer.shadowColor = UIColor(red:0/255, green: 0/255, blue: 0/255, alpha: 1).cgColor
        btnDangKyDichVu.layer.shadowOffset = CGSize(width: 3, height: 3)
        btnDangKyDichVu.layer.shadowOpacity = 1
        btnDangKyDichVu.layer.shadowRadius = 3
    }
}
