//
//  ViewController.swift
//  KhoaLuanTotNghiep2019
//
//  Created by Le Ngoc Bao on 5/9/19.
//  Copyright © 2019 Le Ngoc Bao. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var txtSoDienThoai: UITextField!
    @IBOutlet weak var txtMatKhau: UITextField!
    @IBOutlet weak var btnThoat: UIButton!
    @IBOutlet weak var btnDangNhap: UIButton!
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        txtSoDienThoai.layer.borderWidth=2
        txtMatKhau.layer.borderWidth=2
        
        btnDangNhap.layer.cornerRadius = 10
        btnDangNhap.layer.shadowColor = UIColor(red:0/255, green: 0/255, blue: 0/255, alpha: 1).cgColor
        btnDangNhap.layer.shadowOffset = CGSize(width: 3, height: 3)
        btnDangNhap.layer.shadowOpacity = 1
        btnDangNhap.layer.shadowRadius = 3
    
        btnThoat.layer.cornerRadius = 10
        btnThoat.layer.shadowColor = UIColor(red:0/255, green: 0/255, blue: 0/255, alpha: 1).cgColor
        btnThoat.layer.shadowOffset = CGSize(width: 3, height: 3)
        btnThoat.layer.shadowOpacity = 1
        btnThoat.layer.shadowRadius = 3
        
    }
}

